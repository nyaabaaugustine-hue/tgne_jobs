<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=5, user-scalable=1" name="viewport"/>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <?php echo Theme::partial('theme-meta'); ?>

        <?php echo Theme::header(); ?>

    </head>
    <body <?php echo Theme::bodyAttributes(); ?>>
        <?php echo apply_filters(THEME_FRONT_BODY, null); ?>


        <div id="alert-container" class="toast-notification"></div>

        <?php if(empty($withoutNavbar)): ?>
            <?php echo Theme::partial('navbar'); ?>

        <?php endif; ?>

        <main class="main">
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/header.blade.php ENDPATH**/ ?>