<tbody <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</tbody>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/base/resources/views/components/table/body/index.blade.php ENDPATH**/ ?>