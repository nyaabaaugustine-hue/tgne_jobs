        <?php echo dynamic_sidebar('pre_footer_sidebar'); ?>

    </main>
    <?php if(is_plugin_active('ads')): ?>
        <?php echo apply_filters('ads_render', null, 'footer_before', ['class' => 'my-2 text-center']); ?>

    <?php endif; ?>

    <footer class="footer mt-50">
        <div class="container">
            <div class="row">
                <?php echo dynamic_sidebar('footer_sidebar'); ?>

            </div>
            <div class="footer-bottom mt-50">
                <div class="row">
                    <div class="col-md-6">
                        <span class="font-xs color-text-paragraph">
                            <?php echo BaseHelper::clean(theme_option('copyright')); ?>

                        </span>
                    </div>
                    <div class="col-md-6 text-md-end text-start">
                        <div class="footer-social">
                            <?php echo Menu::renderMenuLocation('footer-menu', [
                                    'options' => ['class' => 'footer_menu'],
                                    'view'    => 'support-menu',
                                ]); ?>

                        </div>
                        <div class="nav float-right language-switcher-footer">
                            <?php if(is_plugin_active('language')): ?>
                                <?php echo $__env->make(JobBoardHelper::viewPath('dashboard.partials.language-switcher'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <?php if(is_plugin_active('ads')): ?>
        <?php echo apply_filters('ads_render', null, 'footer_after', ['class' => 'my-2 text-center']); ?>

    <?php endif; ?>
    <script>
        <?php if(is_plugin_active('job-board')): ?>
            window.currencies = <?php echo json_encode(get_currencies_json()); ?>;
        <?php endif; ?>

        window.alertTranslations = {
            'success': "<?php echo e(__('Success')); ?>",
            'errors': "<?php echo e(__('Errors')); ?>"
        }
    </script>

    <?php echo Theme::footer(); ?>


    <?php if(session()->has('status') || session()->has('success_msg') || session()->has('error_msg') || (isset($errors) && $errors->count() > 0) || isset($error_msg)): ?>
        <script type="text/javascript">
            'use strict';
            window.onload = function () {
                <?php if(session()->has('success_msg')): ?>
                window.showAlert('alert-success', "<?php echo e(__('Success')); ?>", "<?php echo addslashes(session('success_msg')); ?>");
                <?php endif; ?>
                <?php if(session()->has('status')): ?>
                window.showAlert('alert-success', "<?php echo e(__('Success')); ?>", "<?php echo addslashes(session('status')); ?>");
                <?php endif; ?>
                <?php if(session()->has('error_msg')): ?>
                window.showAlert('alert-danger', "<?php echo e(__('Errors')); ?>", "<?php echo addslashes(session('error_msg')); ?>");
                <?php endif; ?>
                <?php if(isset($error_msg)): ?>
                window.showAlert('alert-danger', "<?php echo e(__('Errors')); ?>", "<?php echo addslashes($error_msg); ?>");
                <?php endif; ?>
                <?php if(isset($errors)): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                window.showAlert('alert-danger', "<?php echo e(__('Errors')); ?>", "<?php echo addslashes($error); ?>");
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            };
        </script>
    <?php endif; ?>

    <?php if(theme_option('scroll_to_top', 'yes') === 'yes'): ?>
        <script>
            'use strict';
            $(function() {
                $.scrollUp({
                    scrollText: '<i class="fi-rr-arrow-small-up"></i>',
                    easingType: "linear",
                    scrollSpeed: 900,
                    animation: "fade"
                })
            });
        </script>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/footer.blade.php ENDPATH**/ ?>