<?php for($i = 1 ; $i <= $star; $i++): ?>
    <img alt="star" class="rating-star" src="<?php echo e(Theme::asset()->url('imgs/template/icons/star.svg')); ?>">
<?php endfor; ?>
<?php for($i = 1 ; $i <= (5 - $star); $i++): ?>
    <img alt="star" class="rating-star" src="<?php echo e(Theme::asset()->url('imgs/template/icons/gray-star.svg')); ?>">
<?php endfor; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/rating-star.blade.php ENDPATH**/ ?>