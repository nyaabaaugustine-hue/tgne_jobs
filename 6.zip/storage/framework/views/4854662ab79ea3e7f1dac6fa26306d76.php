<div class="section-box mb-30">
    <div class="container">
        <div class="box-we-hiring">
            <?php if($shortcode->apply_image_left): ?>
                <div class="box-we-hiring-before" style="background: url(<?php echo e(RvMedia::getImageUrl($shortcode->apply_image_left)); ?>) no-repeat 0 0"></div>
            <?php endif; ?>
            <div class="text-1">
                <span class="text-we-are"><?php echo BaseHelper::clean($shortcode->title_1); ?></span>
                <span class="text-hiring"><?php echo BaseHelper::clean($shortcode->title_2); ?></span>
            </div>
            <div class="text-2">
                <?php echo BaseHelper::clean($subtitleText); ?>

            </div>
            <?php if($shortcode->button_apply_link): ?>
                <div class="text-3">
                    <a href="<?php echo e($shortcode->button_apply_link); ?>">
                        <div class="btn btn-apply btn-apply-icon" ><?php echo BaseHelper::clean($shortcode->button_apply_text); ?></div>
                    </a>
                </div>
            <?php endif; ?>

            <?php if($shortcode->apply_image_right): ?>
                <div class="box-we-hiring-after" style="background: url(<?php echo e(RvMedia::getImageUrl($shortcode->apply_image_right)); ?>) no-repeat 0 0"></div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/shortcodes/apply-banner.blade.php ENDPATH**/ ?>