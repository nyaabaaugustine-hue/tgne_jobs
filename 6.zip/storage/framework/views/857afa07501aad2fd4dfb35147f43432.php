<?php if(count($jobs) > 0): ?>
    <?php echo Theme::partial('loading'); ?>


    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($style === 'style-1'): ?>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['card-grid-2 hover-up items', 'featured-job-item' => $job->is_featured]); ?>">
                    <div class="card-grid-2-image-left job-item">
                        <?php if($job->is_featured): ?>
                            <span class="flash"></span>
                        <?php endif; ?>
                        <div class="image-box">
                            <img src="<?php echo e($job->company_logo_thumb); ?>" alt="<?php echo e($job->company->name); ?>">
                        </div>
                        <div class="right-info">
                            <?php if(! $job->hide_company): ?>
                                <a class="name-job" title="<?php echo e($job->company_name); ?>" href="<?php echo e($job->company_url); ?>"><?php echo e($job->company_name); ?></a>
                            <?php endif; ?>
                            <span class="location-small"><?php echo e($job->location); ?></span>
                        </div>
                    </div>
                    <div class="card-block-info">
                        <div class="h6 fw-bold text-truncate">
                            <a href="<?php echo e($job->url); ?>" title="<?php echo e($job->name); ?>"><?php echo e($job->name); ?></a>
                        </div>
                        <div class="mt-5">
                            <?php if($job->jobTypes->isNotEmpty()): ?>
                                <span class="card-briefcase">
                                    <?php $__currentLoopData = $job->jobTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($jobType->name); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </span>
                            <?php endif; ?>
                            <span class="card-time"><?php echo e($job->created_at->diffForHumans()); ?></span></div>
                        <p class="font-sm color-text-paragraph job-description mt-15" title="<?php echo e($job->description); ?>"><?php echo e($job->description); ?></p>
                        <div class="mt-15">
                            <?php if($job->tags->isNotEmpty()): ?>
                                <?php $__currentLoopData = $job->tags->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="btn btn-grey-small mr-5 mb-2" href="<?php echo e($tag->url); ?>"><?php echo e($tag->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <div class="card-2-bottom mt-15">
                            <div class="row">
                                <div class="col-12 salary-information">
                                    <?php echo Theme::partial('salary', compact('job')); ?>

                                </div>
                                <div class="col-12 mt-3">
                                    <?php echo Theme::partial('apply-button', compact('job')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php elseif($style === 'style-3'): ?>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                <div class="card-grid-2 grid-bd-16 hover-up item-grid <?php if($job->is_featured): ?> featured-job-item <?php endif; ?>">
                    <div class="card-grid-2-image">
                        <?php if($job->jobTypes->isNotEmpty()): ?>
                            <span class="lbl-hot bg-green">
                                <?php if($job->jobTypes): ?>
                                    <?php $__currentLoopData = $job->jobTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><?php echo e($jobType->name); ?></span><?php if(!$loop->last): ?>, <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </span>
                        <?php endif; ?>
                        <div class="image-box">
                            <figure>
                                <img src="<?php echo e($job->company_logo_thumb); ?>" alt="<?php echo e($job->name); ?>">
                            </figure>
                        </div>
                    </div>
                    <div class="card-block-info">
                        <div class="h6 font-bold">
                            <a href="<?php echo e($job->url); ?>" class="name-job" title="<?php echo e($job->name); ?>"><?php echo e($job->name); ?></a>
                        </div>
                        <div class="mt-5">
                            <span class="card-location mr-15"><?php echo e($job->location); ?></span>
                            <span class="card-time"><?php echo e($job->created_at->diffForHumans()); ?></span>
                        </div>
                        <div class="card-2-bottom mt-20">
                            <div class="row">
                                <?php if($job->skills->isNotEmpty()): ?>
                                    <div class="col-12 mb-2">
                                        <?php $__currentLoopData = $job->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="btn btn-tags-sm mr-5"><?php echo e($skill->name); ?></span>&nbsp;
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <div class="col-12">
                                    <?php echo Theme::partial('salary', compact('job')); ?>

                                </div>
                            </div>
                        </div>
                        <p class="font-sm color-text-paragraph job-description mt-20"><?php echo e($job->description); ?></p>
                    </div>
                </div>
            </div>
        <?php else: ?>
             <?php ($jobs->loadMissing('metadata')); ?>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                <div class="card-grid-2 grid-bd-16 hover-up item-grid <?php if($job->is_featured): ?> featured-job-item <?php endif; ?>">
                    <div class="card-grid-2-image">
                        <?php if($job->jobTypes->isNotEmpty()): ?>
                            <span class="lbl-hot bg-green">
                                <?php $__currentLoopData = $job->jobTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span><?php echo e($jobType->name); ?></span><?php if(!$loop->last): ?>, <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </span>
                        <?php endif; ?>
                        <div class="image-box">
                            <figure>
                                <img src="<?php echo e($job->getMetaData('featured_image', true) ? RvMedia::getImageUrl($job->getMetaData('featured_image', true)) : $job->company_logo_thumb); ?>" alt="<?php echo e($job->name); ?>">
                            </figure>
                        </div>
                    </div>
                    <div class="card-block-info">
                        <div class="h6 fw-bold">
                            <a href="<?php echo e($job->url); ?>" class="name-job" title="<?php echo e($job->name); ?>"><?php echo e($job->name); ?></a>
                        </div>
                        <div class="mt-5">
                            <span class="card-location mr-15"><?php echo e($job->location); ?></span>
                            <span class="card-time"><?php echo e($job->created_at->diffForHumans()); ?></span>
                        </div>
                        <div class="card-2-bottom mt-20">
                            <div class="row">
                                <?php if($job->skills->isNotEmpty()): ?>
                                    <div class="col-12 mb-2">
                                        <?php $__currentLoopData = $job->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="btn btn-tags-sm mr-5"><?php echo e($skill->name); ?></span>&nbsp;
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <div class="col-12">
                                   <?php echo Theme::partial('salary', compact('job')); ?>

                                </div>
                            </div>
                        </div>
                        <p class="font-sm color-text-paragraph job-description mt-20"><?php echo e($job->description); ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div class="col-12">
        <p class="text-center"><?php echo e(__('No data available')); ?></p>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/views/job-board/partials/job-of-the-day-items.blade.php ENDPATH**/ ?>