<div class="footer-col-2 col-md-2 col-xs-6">
    <div class="h6 mb-20"><?php echo BaseHelper::clean($config['name']); ?></div>
    <?php echo Menu::generateMenu([
            'slug'    => $config['menu_id'],
            'view'    => 'footer-menu',
            'options' => ['class' => 'menu-footer']
        ]); ?>

</div>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/////widgets/custom-menu/templates/frontend.blade.php ENDPATH**/ ?>