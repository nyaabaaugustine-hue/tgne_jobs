<?php if($job->canShowApplyJob()): ?>
    <?php ($classButtonApply = $class ?? 'btn btn-apply-now'); ?>
    <div class="<?php echo e($wrapClass ?? ''); ?>">
        <?php if($job->is_applied): ?>
            <button class="<?php echo e($classButtonApply); ?> disabled" disabled><?php echo e(__('Applied')); ?></button>
        <?php elseif(! $job->isJobOpen()): ?>
            <button disabled
                style="background-color: #f8d7da;  border: 0; background-image: unset"
                class="<?php echo e($classButtonApply); ?> text-danger"
            >
                <?php echo e(__('Closed')); ?>

            </button>
        <?php elseif($job->apply_url): ?>
            <?php if($job->getMetaData('is_direct_redirect', true)): ?>
                <a href="<?php echo e($job->apply_url); ?>" target="_blank">
                    <div class="<?php echo e($classButtonApply); ?>"><?php echo e(__('Apply Now')); ?></div>
                </a>
            <?php else: ?>
                <button class="<?php echo e($classButtonApply); ?>"
                    data-bs-target="#ModalApplyExternalJobForm"
                    data-bs-toggle="modal"
                    data-job-name="<?php echo e($job->name); ?>"
                    data-job-id="<?php echo e($job->id); ?>"
                >
                    <?php echo e(__('Apply Now')); ?>

                </button>
            <?php endif; ?>
        <?php elseif(!auth('account')->check() && !JobBoardHelper::isGuestApplyEnabled()): ?>
            <a href="<?php echo e(route('public.account.login')); ?>">
                <div class="<?php echo e($classButtonApply); ?>"><?php echo e(__('Apply Now')); ?></div>
            </a>
        <?php else: ?>
            <button class="<?php echo e($classButtonApply); ?>"
                    data-job-name="<?php echo e($job->name); ?>"
                    data-job-id="<?php echo e($job->id); ?>"
                    data-bs-toggle="modal"
                    data-bs-target="#ModalApplyJobForm"
            >
                <?php echo e(__('Apply Now')); ?>

            </button>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/apply-button.blade.php ENDPATH**/ ?>