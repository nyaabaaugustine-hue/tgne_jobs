<?php switch($shortcode->style):
    case ('style-2'): ?>
        <section class="section-box mt-110 bg-cat" <?php if($shortcode->background_image): ?> style="background-image: url(<?php echo e(RvMedia::getImageUrl($shortcode->background_image)); ?>);" <?php endif; ?>>
            <div class="section-box wow animate__animated animate__fadeIn">
                <div class="container">
                    <div class="text-center">
                        <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp">
                            <?php echo BaseHelper::clean($shortcode->title); ?>

                        </h2>
                        <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp">
                            <?php echo BaseHelper::clean($shortcode->subtitle); ?>

                        </p>
                    </div>
                    <div class="box-swiper mt-50">
                        <div class="swiper-container swiper-group-5 swiper">
                            <div class="swiper-wrapper pb-70 pt-5">
                                <?php $__currentLoopData = $categories->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide hover-up">
                                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e($job->url); ?>">
                                                <div class="item-logo">
                                                    <div class="image-left">
                                                        <?php if($iconImage = $job->getMetaData('icon_image', true)): ?>
                                                            <img src="<?php echo e(RvMedia::getImageUrl($iconImage)); ?>" alt="<?php echo e($job->name); ?>">
                                                        <?php elseif($icon = $job->getMetaData('icon', true)): ?>
                                                            <i class="<?php echo e($icon); ?>"></i>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="text-info-right">
                                                        <div class="h5" title="<?php echo e($job->name); ?>"><?php echo BaseHelper::clean(Str::limit($job->name, 20) ); ?></div>
                                                        <p class="font-xs">
                                                            <?php if($job->active_jobs_count > 1): ?>
                                                                <?php echo BaseHelper::clean(__(':number <span> Jobs Available </span>', ['number' => $job->active_jobs_count ])); ?>

                                                            <?php elseif($job->active_jobs_count == 1): ?>
                                                                <?php echo BaseHelper::clean(__(':number <span> Job Available </span>', ['number' => $job->active_jobs_count ])); ?>

                                                            <?php else: ?>
                                                                <?php echo BaseHelper::clean(__('No <span> Job Available </span>')); ?>

                                                            <?php endif; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                </div>
            </div>
        </section>
        <?php break; ?>
    <?php default: ?>
        <section class="section-box mt-80" <?php if($shortcode->background_image): ?> style="background-image: url(<?php echo e(RvMedia::getImageUrl($shortcode->background_image)); ?>);" <?php endif; ?>>
            <div class="section-box wow animate__animated animate__fadeIn">
                <div class="container">
                    <div class="text-center">
                        <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp">
                            <?php echo BaseHelper::clean($shortcode->title); ?>

                        </h2>
                        <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp">
                            <?php echo BaseHelper::clean($shortcode->subtitle); ?>

                        </p>
                    </div>
                    <div class="box-swiper mt-50">
                        <div class="swiper-container swiper-group-5 swiper">
                            <div class="swiper-wrapper pb-70 pt-5">
                                <?php $__currentLoopData = $categories->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide hover-up">
                                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e($job->url); ?>">
                                                <div class="item-logo">
                                                    <div class="image-left">
                                                        <?php if($iconImage = $job->getMetaData('icon_image', true)): ?>
                                                            <img src="<?php echo e(RvMedia::getImageUrl($iconImage)); ?>" alt="<?php echo e($job->name); ?>">
                                                        <?php elseif($icon = $job->getMetaData('icon', true)): ?>
                                                            <i class="<?php echo e($icon); ?>"></i>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="text-info-right">
                                                        <div class="h6"><?php echo e($job->name); ?></div>
                                                        <p class="font-xs">
                                                            <?php if($job->active_jobs_count > 1): ?>
                                                                <?php echo BaseHelper::clean(__(':number <span> Jobs Available </span>', ['number' => $job->active_jobs_count ])); ?>

                                                            <?php elseif($job->active_jobs_count == 1): ?>
                                                                <?php echo BaseHelper::clean(__(':number <span> Job Available </span>', ['number' => $job->active_jobs_count ])); ?>

                                                            <?php else: ?>
                                                                <?php echo BaseHelper::clean(__('No <span> Job Available </span>')); ?>

                                                            <?php endif; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                </div>
            </div>
        </section>
        <?php break; ?>
<?php endswitch; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/shortcodes/featured-job-categories.blade.php ENDPATH**/ ?>