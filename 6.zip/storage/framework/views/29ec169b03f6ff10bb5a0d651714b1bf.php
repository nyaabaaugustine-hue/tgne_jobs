<?php if($posts->count() > 0): ?>
    <?php
        $title = $shortcode->title;
        $subtitle = $shortcode->subtitle;
    ?>

    <?php switch($shortcode->style):
        case ('style-2'): ?>
            <section class="section-box mt-50 mb-50">
                <div class="container">
                    <div class="text-start">
                        <?php if($title): ?>
                            <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp">
                                <?php echo BaseHelper::clean($title); ?>

                            </h2>
                        <?php endif; ?>

                        <?php if($subtitle): ?>
                            <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp">
                                <?php echo BaseHelper::clean($subtitle); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="container">
                    <div class="mt-50">
                        <div class="box-swiper style-nav-top">
                            <div class="swiper-container swiper-group-3 swiper">
                                <div class="swiper-wrapper pb-70 pt-5">
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="swiper-slide">
                                            <div class="card-grid-3 hover-up wow animate__animated animate__fadeIn">
                                                <div class="text-center card-grid-3-image">
                                                    <a href="<?php echo e($post->url); ?>">
                                                        <figure>
                                                            <img alt="<?php echo e($post->name); ?>" src="<?php echo e(RvMedia::getImageUrl($post->image, 'featured', false, RvMedia::getDefaultImage())); ?>">
                                                        </figure>
                                                    </a>
                                                </div>
                                                <div class="card-block-info">
                                                    <div class="tags mb-15">
                                                        <?php if($post->tags): ?>
                                                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <a class="btn btn-tag" href="<?php echo e($tag->url); ?>"><?php echo e($tag->name); ?></a>&nbsp;
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </div>
                                                    <h5 class="post-title"><a href="<?php echo e($post->url); ?>"><?php echo e($post->name); ?></a></h5>
                                                    <p class="mt-10 color-text-paragraph font-sm post-description"><?php echo e($post->description); ?></p>
                                                    <div class="card-2-bottom mt-20">
                                                        <div class="row">
                                                            <div class="col-lg-6 col-6">
                                                                <?php
                                                                    $author = $post->author;
                                                                    $isDisplayAuthor = (! theme_option('hide_blog_post_author') && $author->getKey());
                                                                ?>

                                                                <div class="d-flex">
                                                                    <?php if($isDisplayAuthor): ?>
                                                                        <img class="img-rounded" src="<?php echo e($author->avatar_url); ?>" alt="<?php echo e($author->name); ?>">
                                                                    <?php endif; ?>

                                                                    <div class="info-right-img">
                                                                        <?php if($isDisplayAuthor): ?>
                                                                            <span class="font-sm font-bold color-brand-1 op-70"><?php echo e($author->name); ?></span>
                                                                            <br>
                                                                        <?php endif; ?>
                                                                        <span class="font-xs color-text-paragraph-2"><?php echo e($post->created_at->translatedFormat('M d, Y')); ?></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['col-lg-6 text-md-end col-6', 'pt-15' => $isDisplayAuthor]); ?>">
                                                                <span class="color-text-paragraph-2 font-xs">
                                                                <?php
                                                                    $timeReading = $post->getMetaData('time_to_read', true) ?:  number_format(strlen(strip_tags($post->content)) / 300);
                                                                ?>

                                                                <?php if($timeReading > 1): ?>
                                                                    <?php echo e(__(':time mins to read', ['time' => $timeReading])); ?>

                                                                <?php elseif($timeReading === 1): ?>
                                                                    <?php echo e(__(':time min to read', ['time' => $timeReading])); ?>

                                                                <?php endif; ?>
                                                            </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div>
                        </div>
                        <div class="text-center">
                            <a class="btn btn-brand-1 mt--30 hover-up view-more-posts" href="<?php echo e(get_blog_page_url()); ?>">
                                <?php echo e(__('View more')); ?>

                            </a>
                        </div>
                    </div>
                </div>
            </section>
            <?php break; ?>
        <?php default: ?>
            <section class="section-box mt-50 mb-50 news-or-blogs">
                <div class="container">
                    <div class="text-center">
                        <?php if($title): ?>
                            <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp"><?php echo BaseHelper::clean($title); ?></h2>
                        <?php endif; ?>

                        <?php if($subtitle): ?>
                            <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp"><?php echo BaseHelper::clean($subtitle); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="container">
                    <div class="mt-50">
                        <div class="box-swiper style-nav-top">
                            <div class="swiper-container swiper-group-3 swiper">
                                <div class="swiper-wrapper pb-70 pt-5">
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="swiper-slide">
                                            <div class="card-grid-3 hover-up wow animate__animated animate__fadeIn">
                                                <div class="text-center card-grid-3-image">
                                                    <a href="<?php echo e($post->url); ?>">
                                                        <figure>
                                                            <img alt="<?php echo e($post->name); ?>" src="<?php echo e(RvMedia::getImageUrl($post->image, 'featured', false, RvMedia::getDefaultImage())); ?>">
                                                        </figure>
                                                    </a>
                                                </div>
                                                <div class="card-block-info">
                                                    <div class="tags mb-15">
                                                        <?php if($post->tags): ?>
                                                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <a class="btn btn-tag" href="<?php echo e($tag->url); ?>"><?php echo e($tag->name); ?></a>&nbsp;
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </div>
                                                    <h5><a href="<?php echo e($post->url); ?>"><?php echo e($post->name); ?></a></h5>
                                                    <p class="mt-10 color-text-paragraph font-sm post-description"><?php echo e($post->description); ?></p>
                                                    <div class="card-2-bottom mt-20">
                                                        <div class="row">
                                                            <div class="col-lg-6 col-6">
                                                                <?php
                                                                    $author = $post->author;
                                                                    $isDisplayAuthor = (! theme_option('hide_blog_post_author') && $author->getKey());
                                                                ?>

                                                                <div class="d-flex">
                                                                    <?php if($isDisplayAuthor): ?>
                                                                        <img class="img-rounded" src="<?php echo e($author->avatar_url); ?>" alt="<?php echo e($author->name); ?>">
                                                                    <?php endif; ?>
                                                                    <div class="info-right-img">
                                                                        <?php if($isDisplayAuthor): ?>
                                                                            <span class="font-sm font-bold color-brand-1 op-70"><?php echo e($author->name); ?></span>
                                                                            <br>
                                                                        <?php endif; ?>

                                                                        <span class="font-xs color-text-paragraph-2"><?php echo e($post->created_at->translatedFormat('M d, Y')); ?></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['col-lg-6 text-md-end col-6', 'pt-15' => $isDisplayAuthor]); ?>">
                                                                <span class="color-text-paragraph-2 font-xs">
                                                                    <?php
                                                                        $timeReading = $post->getMetaData('time_to_read', true) ?:  number_format(strlen(strip_tags($post->content)) / 300);
                                                                    ?>

                                                                    <?php if($timeReading > 1): ?>
                                                                        <?php echo e(__(':time mins to read', ['time' => $timeReading])); ?>

                                                                    <?php elseif($timeReading === 1): ?>
                                                                        <?php echo e(__(':time min to read', ['time' => $timeReading])); ?>

                                                                    <?php endif; ?>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div>
                            <div class="text-center">
                                <a class="btn btn-brand-1 mt--30 hover-up view-more-posts" href="<?php echo e(get_blog_page_url()); ?>">
                                    <?php echo e(__('View more')); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <?php break; ?>
    <?php endswitch; ?>
<?php endif; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/shortcodes/news-and-blogs.blade.php ENDPATH**/ ?>