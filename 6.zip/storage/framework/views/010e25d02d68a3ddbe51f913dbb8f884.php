<?php
    $currencies = get_all_currencies();
    $supportedLocales = Language::getSupportedLocales();
    if (empty($options)) {
        $options = [
            'before' => '',
            'lang_flag' => true,
            'lang_name' => true,
            'class' => '',
            'after' => '',
        ];
    }

    $displayLanguageSwitcher = $supportedLocales && count($supportedLocales) > 1;
    $displayCurrencySwitcher = $currencies->count() > 1;
?>

<?php if($displayLanguageSwitcher || $displayCurrencySwitcher): ?>
    <div class="mobile-menu-switcher">
        <ul class="mobile-menu font-heading">
            <?php if($displayCurrencySwitcher): ?>
                <li class="has-children"><span class="menu-expand"><i class="fi-rr-angle-small-down"></i></span>
                    <a>
                        <?php echo e($currencyActive = get_application_currency()->title); ?>

                        <div class="arrow-down"></div>
                    </a>
                    <ul class="sub-menu" style="display: none;">
                        <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($currency->title != $currencyActive): ?>
                                <li>
                                    <a href="<?php echo e(route('public.change-currency', $currency->title)); ?>">
                                        <?php echo e($currency->title); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
            <?php endif; ?>

            <?php if($displayLanguageSwitcher): ?>
                <?php
                    $languageDisplay = setting('language_display', 'all');
                    $showRelated = setting('language_show_default_item_if_current_version_not_existed', true);
                ?>
                <li class="has-children"><span class="menu-expand"><i class="fi-rr-angle-small-down"></i></span>
                    <a>
                        <?php echo language_flag(Language::getCurrentLocaleFlag(), Language::getCurrentLocaleName()); ?>

                        <span>&nbsp;<?php echo e(Language::getCurrentLocaleName()); ?></span>
                        <div class="arrow-down"></div>
                    </a>
                    <ul class="sub-menu" style="display: none;">
                        <?php $__currentLoopData = $supportedLocales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($localeCode != Language::getCurrentLocale()): ?>
                                <li>
                                    <a href="<?php echo e($showRelated ? Language::getLocalizedURL($localeCode) : url($localeCode)); ?>">
                                        <?php if(Arr::get($options, 'lang_flag', true) && ($languageDisplay == 'all' || $languageDisplay == 'flag')): ?>
                                            <?php echo language_flag($properties['lang_flag'], $properties['lang_name']); ?>

                                        <?php endif; ?>
                                        <?php if(Arr::get($options, 'lang_name', true) && ($languageDisplay == 'all' || $languageDisplay == 'name')): ?>
                                            &nbsp;<span>&nbsp;<?php echo e($properties['lang_name']); ?></span>
                                        <?php endif; ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
            <?php endif; ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/language-and-currency-switcher-mobile.blade.php ENDPATH**/ ?>