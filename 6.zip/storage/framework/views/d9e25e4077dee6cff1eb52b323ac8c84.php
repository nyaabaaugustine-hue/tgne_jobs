<td <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</td>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/base/resources/views/components/table/body/cell.blade.php ENDPATH**/ ?>