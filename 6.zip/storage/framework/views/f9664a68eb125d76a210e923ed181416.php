<svg class="icon  svg-icon-ti-ti-ad-circle"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
  >
  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
  <path d="M12 12m-10 0a10 10 0 1 0 20 0a10 10 0 1 0 -20 0" />
  <path d="M7 15v-4.5a1.5 1.5 0 0 1 3 0v4.5" />
  <path d="M7 13h3" />
  <path d="M14 9v6h1a2 2 0 0 0 2 -2v-2a2 2 0 0 0 -2 -2h-1z" />
</svg><?php /**PATH C:\Users\TGNE\Pictures\JobBox\storage\framework\views/fd978891e1ac33723cbffddc6658659a.blade.php ENDPATH**/ ?>