<div class="footer-col-1 col-md-3 col-sm-12">
    <a href="<?php echo e(route('public.index')); ?>" aria-label="<?php echo e(theme_option('site_title')); ?>">
        <img
            alt="<?php echo e(setting('site_title')); ?>"
            src="<?php echo e(RvMedia::getImageUrl($config['logo'] ?: theme_option('theme-jobbox-logo'))); ?>"
        >
    </a>
    <div class="mt-20 mb-20 font-xs color-text-paragraph-2">
        <?php echo BaseHelper::clean($config['introduction']); ?>

    </div>

    <?php if($socialLinks = json_decode(theme_option('social_links'))): ?>
        <div class="footer-social">
            <?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($social = collect($social)->pluck('value', 'key')); ?>
                <a class="icon-socials" title="<?php echo e($social->get('social-name')); ?>" href="<?php echo e($social->get('social-url')); ?>" target="_blank">
                    <img src="<?php echo e(RvMedia::getImageUrl($social->get('social-icon'))); ?>" alt="<?php echo e($social->get('social-name')); ?>">
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/////widgets/site-information/templates/frontend.blade.php ENDPATH**/ ?>