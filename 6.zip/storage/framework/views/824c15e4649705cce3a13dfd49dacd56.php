<?php
    $supportedLocales = Language::getSupportedLocales();
    if (empty($options)) {
        $options = [
            'before' => '',
            'lang_flag' => true,
            'lang_name' => true,
            'class' => '',
            'after' => '',
        ];
    }

    $languageDisplay = setting('language_display', 'all');
    $showRelated = setting('language_show_default_item_if_current_version_not_existed', true);
?>

<?php if(setting('language_switcher_display', 'dropdown') == 'dropdown'): ?>
    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'dropdown nav-item',
        'me-5' => !is_in_admin(),
        'me-2' => is_in_admin(),
    ]); ?>">
        <?php if($supportedLocales && count($supportedLocales) > 1): ?>
            <?php echo Arr::get($options, 'before'); ?>

            <a
                class="dropdown-toggle"
                id="dropdownLanguage"
                data-bs-toggle="dropdown"
                href="#"
                aria-expanded="false"
            >
                <span class="text-language">
                    <?php if(Arr::get($options, 'lang_flag', true) && ($languageDisplay == 'all' || $languageDisplay == 'flag')): ?>
                        <?php echo language_flag(Language::getCurrentLocaleFlag(), Language::getCurrentLocaleName()); ?>

                    <?php endif; ?>
                    <?php if(Arr::get($options, 'lang_name', true) && ($languageDisplay == 'all' || $languageDisplay == 'name')): ?>
                        <?php echo e(Language::getCurrentLocaleName()); ?>

                    <?php endif; ?>
                    <span class="caret"></span>
                </span>
            </a>
            <div
                class="dropdown-menu dropdown-menu-end float-end"
                aria-labelledby="dropdownLanguage"
            >
                <?php $__currentLoopData = $supportedLocales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($localeCode != Language::getCurrentLocale()): ?>
                        <a
                            class="dropdown-item"
                            href="<?php echo e($showRelated ? Language::getLocalizedURL($localeCode) : url($localeCode)); ?>"
                        >
                            <?php if(Arr::get($options, 'lang_flag', true) && ($languageDisplay == 'all' || $languageDisplay == 'flag')): ?>
                                <?php echo language_flag($properties['lang_flag'], $properties['lang_name']); ?>

                            <?php endif; ?>
                            <?php if(Arr::get($options, 'lang_name', true) && ($languageDisplay == 'all' || $languageDisplay == 'name')): ?>
                                <span><?php echo e($properties['lang_name']); ?></span>
                            <?php endif; ?>
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo Arr::get($options, 'after'); ?>

        <?php endif; ?>
        <?php if(!is_in_admin()): ?>
            &nbsp;&nbsp;
            <?php echo $__env->make(JobBoardHelper::viewPath('dashboard.partials.currency-switcher'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </li>
<?php else: ?>
    <?php if($supportedLocales && count($supportedLocales) > 1): ?>
        <?php $__currentLoopData = $supportedLocales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($localeCode != Language::getCurrentLocale()): ?>
                <li class="me-3">
                    <a href="<?php echo e($showRelated ? Language::getLocalizedURL($localeCode) : url($localeCode)); ?>">
                        <?php if(Arr::get($options, 'lang_flag', true) && ($languageDisplay == 'all' || $languageDisplay == 'flag')): ?>
                            <?php echo language_flag($properties['lang_flag'], $properties['lang_name']); ?>

                        <?php endif; ?>
                        <?php if(Arr::get($options, 'lang_name', true) && ($languageDisplay == 'all' || $languageDisplay == 'name')): ?>
                            <span><?php echo e($properties['lang_name']); ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    &nbsp;&nbsp;
    <?php echo $__env->make(JobBoardHelper::viewPath('dashboard.partials.currency-switcher'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>

<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/plugins/job-board/resources/views/themes/dashboard/partials/language-switcher.blade.php ENDPATH**/ ?>