<?php echo Form::open($attributes->getAttributes()); ?>

    <?php echo e($slot); ?>

<?php echo Form::close(); ?>

<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/base/resources/views/components/form/index.blade.php ENDPATH**/ ?>