<div <?php echo e($attributes->merge(['class' => 'card-footer'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/base/resources/views/components/card/footer/index.blade.php ENDPATH**/ ?>