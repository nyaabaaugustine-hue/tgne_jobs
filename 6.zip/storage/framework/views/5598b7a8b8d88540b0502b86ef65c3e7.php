<?php if(is_plugin_active('job-board')): ?>
    <?php
        if ($categoryIds = request()->input('job_categories', [])) {
            $categories = Botble\JobBoard\Models\Category::query()
                ->whereIn('id', (array) $categoryIds)
                ->pluck('name')
                ->all();
        } else {
            $categories = [];
        }
    ?>
    <div class="form-find position-relative mt-40 wow animate__animated animate__fadeIn" data-wow-delay=".2s">
        <?php echo Form::open(['url' => JobBoardHelper::getJobsPageURL(), 'method' => 'GET', 'data-quick-search-url' => route('public.ajax.quick-search-jobs')]); ?>

            <?php if(isset($style)): ?>
                <input class="form-input input-keysearch mr-10" name="keyword" type="text" value="<?php echo e(BaseHelper::stringify(request()->query('keyword'))); ?>" placeholder="<?php echo e(__('Your keyword...')); ?>">
            <?php endif; ?>

            <?php if(is_plugin_active('job-board')): ?>
                <div class="box-industry">
                    <select
                        class="form-input mr-10 select-active input-industry job-category" name="job_categories[]">
                        <option value=""><?php echo e($categories ? implode(', ', $categories) : __('Industry')); ?></option>
                    </select>
                </div>
            <?php endif; ?>

            <?php if(! theme_option('hide_job_location_filter') && is_plugin_active('location')): ?>
                <select class="form-input mr-10 select-location" name="location" data-location-type="<?php echo e(theme_option('job_location_filter_by', 'state')); ?>">
                    <option value=""><?php echo e(__('Location')); ?></option>
                </select>
            <?php endif; ?>

            <?php if(!isset($style)): ?>
                <input class="form-input input-keysearch mr-10" name="keyword" value="<?php echo e(BaseHelper::stringify(request()->query('keyword'))); ?>" type="text" placeholder="<?php echo e(__('Your keyword...')); ?>">
            <?php endif; ?>

            <div class="search-btn-group">
                <button class="btn btn-default btn-find font-sm"><?php echo e(__('Search')); ?></button>
                <button type="button" class="btn btn-default font-sm btn-advanced-filter"><?php echo e(__('Advanced Filter')); ?></button>
            </div>
        <?php echo Form::close(); ?>

    </div>
    <?php if($trendingKeywords): ?>
        <div class="list-tags-banner mt-60 wow animate__animated animate__fadeInUp" data-wow-delay=".3s">
            <strong><?php echo e(__('Popular Searches:')); ?></strong>
            <?php if($keywords = array_map('trim', array_filter(explode(',', $trendingKeywords)))): ?>
                <?php $__currentLoopData = $keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(JobBoardHelper::getJobsPageURL() . '?keyword=' . $item); ?>"><?php echo e($item); ?></a><?php echo e(! $loop->last ? ',' : ''); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/job-search-box.blade.php ENDPATH**/ ?>