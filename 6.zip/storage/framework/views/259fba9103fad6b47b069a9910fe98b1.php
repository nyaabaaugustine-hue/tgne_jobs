<div
    class="collapse navbar-collapse"
    id="sidebar-menu"
>
    <?php echo $__env->make('core/base::layouts.partials.navbar-nav', [
        'autoClose' => 'false',
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/base/resources/views/layouts/vertical/partials/sidebar.blade.php ENDPATH**/ ?>