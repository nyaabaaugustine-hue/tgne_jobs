<input
    class="form-check-input m-0 align-middle checkboxes"
    type="checkbox"
    name="id[]"
    value="<?php echo e($id); ?>"
>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/table/resources/views/partials/checkbox.blade.php ENDPATH**/ ?>