<svg class="icon icon-left svg-icon-ti-ti-refresh"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
  >
  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
  <path d="M20 11a8.1 8.1 0 0 0 -15.5 -2m-.5 -4v4h4" />
  <path d="M4 13a8.1 8.1 0 0 0 15.5 2m.5 4v-4h-4" />
</svg><?php /**PATH C:\Users\TGNE\Pictures\JobBox\storage\framework\views/ce5ce49c08d46926e721563fd894ee73.blade.php ENDPATH**/ ?>