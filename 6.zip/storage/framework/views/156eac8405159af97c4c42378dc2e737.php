<?php
    $currency = $job->currency->getKey() ? $job->currency : get_application_currency();
?>

<?php if($job->hide_salary): ?>
    <span class="text-muted"><?php echo e(__('Attractive')); ?></span>
<?php elseif($job->salary_from || $job->salary_to): ?>
    <?php if(! JobBoardHelper::isSalaryHiddenForGuests()): ?>
        <?php if($job->salary_from && $job->salary_to): ?>
            <span class="card-text-price" title="<?php echo e(format_price($job->salary_from, $currency)); ?> - <?php echo e(format_price($job->salary_to, $currency)); ?>">
            <?php echo e(format_price($job->salary_from, $currency)); ?> - <?php echo e(format_price($job->salary_to, $currency)); ?>

        </span>
        <?php elseif($job->salary_from): ?>
            <span class="card-text-price" title="<?php echo e(__('From :price', ['price' => format_price($job->salary_from, $currency)])); ?>">
            <?php echo e(__('From :price', ['price' => format_price($job->salary_from, $currency)])); ?>

        </span>
        <?php elseif($job->salary_to): ?>
            <span class="card-text-price" title="<?php echo e(__('Upto :price', ['price' => format_price($job->salary_to, $currency)])); ?>">
            <?php echo e(__('Upto :price', ['price' => format_price($job->salary_to, $currency)])); ?>

        </span>
        <?php endif; ?>
        <span class="text-muted">/<?php echo e($job->salary_range->label()); ?></span>
    <?php else: ?>
        <a class="job-hidden-job-for-guest-text" href="<?php echo e(route('public.account.login')); ?>">
            <?php if (isset($component)) { $__componentOriginal73995948b3bd877b76251b40caf28170 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73995948b3bd877b76251b40caf28170 = $attributes; } ?>
<?php $component = Botble\Icon\View\Components\Icon::resolve(['name' => 'ti ti-coin'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('core::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Botble\Icon\View\Components\Icon::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73995948b3bd877b76251b40caf28170)): ?>
<?php $attributes = $__attributesOriginal73995948b3bd877b76251b40caf28170; ?>
<?php unset($__attributesOriginal73995948b3bd877b76251b40caf28170); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73995948b3bd877b76251b40caf28170)): ?>
<?php $component = $__componentOriginal73995948b3bd877b76251b40caf28170; ?>
<?php unset($__componentOriginal73995948b3bd877b76251b40caf28170); ?>
<?php endif; ?>
            <?php echo e(__('Sign in to view salary')); ?>

        </a>
    <?php endif; ?>
<?php else: ?>
    <span class="text-muted"><?php echo e(__('Attractive')); ?></span>
<?php endif; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/salary.blade.php ENDPATH**/ ?>