<?php echo Theme::partial('header'); ?>


<div class="main-content">
    <div class="page-content" id="app">
        <?php if(is_plugin_active('ads')): ?>
            <?php echo apply_filters('ads_render', null, 'main_content_before', ['class' => 'my-2 text-center']); ?>

        <?php endif; ?>

        <?php echo Theme::content(); ?>


        <?php if(is_plugin_active('ads')): ?>
            <?php echo apply_filters('ads_render', null, 'main_content_after', ['class' => 'my-2 text-center']); ?>

        <?php endif; ?>
    </div>
</div>

<?php echo Theme::partial('footer'); ?>

<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/layouts/homepage.blade.php ENDPATH**/ ?>