<?php ($isEnabledAnimation = theme_option('enabled_animation_when_loading_page', 'yes') === 'yes'); ?>

<?php switch($shortcode->style):
    case ('style-2'): ?>
        <div class="bg-homepage1"></div>
        <section class="section-box">
            <div class="banner-hero hero-2" <?php if($shortcode->background_image): ?> style="background-image: url(<?php echo e(RvMedia::getImageUrl($shortcode->background_image)); ?>) !important;" <?php endif; ?>>
                <div class="banner-inner">
                    <div class="block-banner">
                        <h1 class="text-42 color-white wow animate__animated animate__fadeInUp">
                            <?php echo BaseHelper::clean(str_replace($shortcode->highlight_text, '<span class="color-green">' . $shortcode->highlight_text . '</span>', $shortcode->title)); ?>

                        </h1>
                        <div class="font-lg font-regular color-white mt-20 wow animate__animated animate__fadeInUp" data-wow-delay=".1s">
                            <?php echo BaseHelper::clean($shortcode->description); ?>

                        </div>
                        <?php echo Theme::partial('job-search-box', ['trendingKeywords' => $shortcode->trending_keywords]); ?>

                    </div>
                    <div class="mt-60">
                        <div class="row">
                            <?php for($i = 1; $i <= 4 ; $i++): ?>
                                <?php if($shortcode->{'counter_title_' . $i}): ?>
                                <div class="col-lg-3 col-sm-3 col-6 text-center mb-20">
                                    <div class="d-inline-block text-start">
                                        <h4 class="color-white">
                                            <span class="count">
                                                <?php echo BaseHelper::clean($shortcode->{'counter_number_' . $i}); ?>

                                            </span>
                                        </h4>
                                        <p class="font-sm color-text-mutted"><?php echo e($shortcode->{'counter_title_' . $i}); ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="list-brands mt-40 mb-30">
                    <div class="box-swiper">
                        <div class="swiper-container swiper-group-9 swiper">
                            <div class="swiper-wrapper">
                                <?php $__currentLoopData = $featuredCompanies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide">
                                        <a href="<?php echo e($company->url); ?>">
                                            <img src="<?php echo e(RvMedia::getImageUrl($company->logo_thumb)); ?>" alt="<?php echo e($company->name); ?>">
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php break; ?>

    <?php case ('style-3'): ?>
        <section class="section-box">
            <div class="banner-hero hero-2 hero-3" <?php if($shortcode->background_image): ?> style="background-image: url(<?php echo e(RvMedia::getImageUrl($shortcode->background_image)); ?>) !important;" <?php endif; ?>>
                <div class="banner-inner">
                    <div class="block-banner">
                        <h1 class="text-42 color-white wow animate__animated animate__fadeInUp">
                            <?php echo BaseHelper::clean(str_replace($shortcode->highlight_text, '<span class="color-green">'. $shortcode->highlight_text .'</span>', $shortcode->title)); ?>

                        </h1>
                        <div class="font-lg font-regular color-white mt-20 wow animate__animated animate__fadeInUp" data-wow-delay=".1s">
                            <?php echo BaseHelper::clean($shortcode->description); ?>

                        </div>

                        <?php echo Theme::partial('job-search-box', ['trendingKeywords' => $shortcode->trending_keywords]); ?>

                    </div>
                </div>
                <div class="container mt-60">
                    <div class="box-swiper mt-50">
                        <div class="swiper-container swiper-group-5 swiper">
                            <div class="swiper-wrapper pb-25 pt-5">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide hover-up">
                                        <a href="<?php echo e($category->url); ?>">
                                            <div class="item-logo">
                                                <div class="image-left">
                                                    <?php if($iconImage = $category->getMetaData('icon_image', true)): ?>
                                                        <img src="<?php echo e(RvMedia::getImageUrl($iconImage)); ?>" alt="<?php echo e($category->name); ?>">
                                                    <?php elseif($icon = $category->getMetaData('icon', true)): ?>
                                                        <i class="<?php echo e($icon); ?>"></i>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="text-info-right">
                                                    <h4><?php echo BaseHelper::clean($category->name); ?></h4>
                                                    <p class="font-xs">
                                                        <?php echo BaseHelper::clean(__(':count <span>Jobs Available</span>', ['count' => $category->jobs_count])); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="swiper-pagination swiper-pagination-style-border"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php break; ?>

    <?php case ('style-4'): ?>
        <section class="section-box mb-70">
            <div class="banner-hero hero-1 banner-homepage6" <?php if($shortcode->background_image): ?> style="background-image: url(<?php echo e(RvMedia::getImageUrl($shortcode->background_image)); ?>) !important;" <?php endif; ?>>
                <div class="banner-inner py-4">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12">
                            <div class="block-banner text-center pb-40 pt-40">
                                <h1 class="heading-banner wow animate__ animate__fadeInUp animated">
                                    <?php echo BaseHelper::clean(str_replace($shortcode->highlight_text, '<span class="color-brand-2">' . $shortcode->highlight_text . '</span>', $shortcode->title)); ?>

                                </h1>
                                <p class="font-lg color-text-paragraph mt-20"><?php echo BaseHelper::clean($shortcode->description); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="box-search-2">
                        <div class="block-banner form-none-shadow">
                            <?php echo Theme::partial('job-search-box', ['style' => $shortcode->style, 'trendingKeywords' => $shortcode->trending_keywords]); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php break; ?>

    <?php case ('style-5'): ?>
        <section class="section-box mb-70">
            <div class="banner-hero hero-1 banner-homepage5" <?php if($shortcode->background_image): ?> style="background-image: url(<?php echo e(RvMedia::getImageUrl($shortcode->background_image)); ?>) !important;" <?php endif; ?>>
                <div class="banner-inner">
                    <div class="row">
                        <div class="col-xl-7 col-lg-12">
                            <div class="block-banner">
                                <h1 class="heading-banner wow animate__animated animate__fadeInUp">
                                    <?php echo BaseHelper::clean($shortcode->title); ?>

                                </h1>
                                <div class="banner-description mt-20 wow animate__animated animate__fadeInUp" data-wow-delay=".1s">
                                    <?php echo BaseHelper::clean($shortcode->description); ?>

                                </div>
                                <div class="mt-30">
                                    <?php if($shortcode->primary_button_url && $shortcode->primary_button_label): ?>
                                        <a href="<?php echo e($shortcode->primary_button_url); ?>" class="btn btn-default mr-15"><?php echo e($shortcode->primary_button_label); ?></a>
                                    <?php endif; ?>
                                    <?php if($shortcode->secondary_button_url && $shortcode->secondary_button_label): ?>
                                        <a href="<?php echo e($shortcode->secondary_button_url); ?>" class="btn btn-border-brand-2"><?php echo e($shortcode->secondary_button_label); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-5 col-lg-12 d-none d-xl-block col-md-6">
                            <div class="banner-imgs">
                                <?php for($i = 1; $i <= 6; $i++): ?>
                                    <div class="banner-<?php echo e($i); ?> shape-1">
                                        <img class="img-responsive" alt="<?php echo e($i); ?>" src="<?php echo e(RvMedia::getImageUrl($shortcode->{'banner_image_' . $i})); ?>">
                                    </div>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                    <div class="box-search-2">
                        <div class="block-banner">
                            <?php echo Theme::partial('job-search-box', ['trendingKeywords' => $shortcode->trending_keywords]); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php break; ?>

    <?php default: ?>
        <div class="bg-homepage1" <?php if($shortcode->background_image): ?> style="background-image: url(<?php echo e(RvMedia::getImageUrl($shortcode->background_image)); ?>) !important;" <?php endif; ?>></div>
        <section class="section-box">
            <div class="banner-hero hero-1">
                <div class="banner-inner">
                    <div class="row">
                        <div class="col-xl-8 col-lg-12">
                            <div class="block-banner">
                                <h1 class="heading-banner wow animate__animated animate__fadeInUp">
                                    <?php echo BaseHelper::clean(str_replace($shortcode->highlight_text, '<span class="color-brand-2">' . $shortcode->highlight_text . '</span>', $shortcode->title)); ?>

                                </h1>
                                <div class="banner-description mt-20 wow animate__animated animate__fadeInUp" data-wow-delay=".1s">
                                    <?php echo BaseHelper::clean($shortcode->description); ?>

                                </div>
                                <?php echo Theme::partial('job-search-box', ['trendingKeywords' => $shortcode->trending_keywords]); ?>

                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-12 d-none d-xl-block col-md-6">
                            <div class="banner-imgs">
                                <?php if($url = $shortcode->banner_image_1): ?>
                                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['block-1', 'shape-1' => $isEnabledAnimation]); ?>">
                                        <img class="img-responsive" alt="<?php echo e($shortcode->banner_image_1); ?>" src="<?php echo e(RvMedia::getImageUrl($url)); ?>">
                                    </div>
                                <?php endif; ?>
                                <?php if($url = $shortcode->banner_image_2): ?>
                                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['block-2', 'shape-2' => $isEnabledAnimation]); ?>">
                                        <img class="img-responsive" alt="<?php echo e($shortcode->banner_image_2); ?>" src="<?php echo e(RvMedia::getImageUrl($url)); ?>">
                                    </div>
                                <?php endif; ?>
                                <?php if($url = $shortcode->icon_top_banner): ?>
                                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['block-3', 'shape-3' => $isEnabledAnimation]); ?>">
                                        <img class="img-responsive" alt="<?php echo e($shortcode->icon_top_banner); ?>" src="<?php echo e(RvMedia::getImageUrl($url)); ?>">
                                    </div>
                                <?php endif; ?>
                                <?php if($url = $shortcode->icon_bottom_banner): ?>
                                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['block-4', 'shape-4' => $isEnabledAnimation]); ?>">
                                        <img class="img-responsive" alt="<?php echo e($shortcode->icon_bottom_banner); ?>" src="<?php echo e(RvMedia::getImageUrl($url)); ?>">
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php break; ?>
<?php endswitch; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/shortcodes/search-box.blade.php ENDPATH**/ ?>