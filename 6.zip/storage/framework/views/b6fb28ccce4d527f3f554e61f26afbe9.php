<th <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</th>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/base/resources/views/components/table/header/cell.blade.php ENDPATH**/ ?>