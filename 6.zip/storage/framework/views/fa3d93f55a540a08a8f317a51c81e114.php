<?php switch($shortcode->style):
    case ('style-2'): ?>
        <section class="section-box mt-30 job-of-the-day">
            <div class="container">
                <div class="text-start">
                    <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp">
                        <?php echo BaseHelper::clean($shortcode->title); ?>

                    </h2>
                    <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp">
                        <?php echo BaseHelper::clean($shortcode->subtitle); ?>

                    </p>
                    <?php if(count($categories)): ?>
                        <div class="list-tabs mt-40">
                        <div class="nav nav-tabs" role="tablist">
                            <?php $__currentLoopData = $categories->loadMissing('metadata'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div role="tab">
                                    <a
                                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $loop->first, 'category-item']); ?>"
                                        id="nav-tab-job-<?php echo e($category->id); ?>"
                                        href="#tab-job-<?php echo e($category->id); ?>"
                                        data-url="<?php echo e(route('public.ajax.jobs-by-category', $category->getKey())); ?>?limit=<?php echo e((int)$shortcode->limit ?: 8); ?>"
                                        data-style="<?php echo e($shortcode->style); ?>"
                                    >
                                        <?php if($iconImage = $category->getMetaData('icon_image', true)): ?>
                                            <img src="<?php echo e(RvMedia::getImageUrl($iconImage)); ?>" alt="<?php echo e($category->name); ?>">
                                        <?php elseif($icon = $category->getMetaData('icon', true)): ?>
                                            <i class="<?php echo e($icon); ?>"></i>
                                        <?php endif; ?>
                                        <?php echo e($category->name); ?>

                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php if(count($categories)): ?>
                    <div class="mt-50">
                        <div class="tab-content" id="myTabContent-1">
                            <div
                                class="<?php echo \Illuminate\Support\Arr::toCssClasses(['tab-pane fade show active']); ?>"
                                id="tab-job-<?php echo e($firstCategoryId = $categories->first()->id); ?>"
                                aria-labelledby="tab-job-<?php echo e($firstCategoryId); ?>"
                            >
                            <div class="row job-of-the-day-list">
                                <?php echo $__env->make(Theme::getThemeNamespace('views.job-board.partials.job-of-the-day-items'), [
                                    'jobs' => $jobs,
                                    'style' => $shortcode->style
                                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                </div>
            </div>
        </section>
        <?php break; ?>
    <?php case ('style-3'): ?>
        <section class="section-box mt-70 job-of-the-day">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp">
                        <?php echo BaseHelper::clean($shortcode->title); ?>

                    </h2>
                    <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp">
                        <?php echo BaseHelper::clean($shortcode->subtitle); ?>

                    </p>
                    <?php if(count($categories)): ?>
                        <div class="list-tabs mt-40">
                            <div class="nav nav-tabs" role="tablist">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div role="tab">
                                        <a
                                            class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $loop->first, 'category-item']); ?>"
                                            id="nav-tab-job-<?php echo e($category->id); ?>"
                                            href="#tab-job-<?php echo e($category->id); ?>"
                                            data-style="<?php echo e($shortcode->style); ?>"
                                            data-url="<?php echo e(route('public.ajax.jobs-by-category', $category->getKey())); ?>?limit=<?php echo e((int)$shortcode->limit ?: 8); ?>"
                                        >
                                            <img src="<?php echo e(RvMedia::getImageUrl($category->getMetadata('icon_image', true))); ?>" alt="<?php echo e($category->name); ?>">
                                            <?php echo e($category->name); ?>

                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if(count($categories)): ?>
                    <div class="mt-50">
                        <div class="tab-content" id="myTabContent-1">
                            <div
                                class="<?php echo \Illuminate\Support\Arr::toCssClasses(['tab-pane fade show active']); ?>"
                                id="tab-job-<?php echo e($firstCategoryId = $categories->first()->id); ?>"
                                data-style="<?php echo e($shortcode->style); ?>"
                                aria-labelledby="tab-job-<?php echo e($firstCategoryId); ?>"
                            >
                            <div class="row job-of-the-day-list">
                                <?php echo $__env->make(Theme::getThemeNamespace('views.job-board.partials.job-of-the-day-items'), [
                                    'jobs' => $jobs,
                                    'style' => $shortcode->style
                                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            </div>
        </section>
        <?php break; ?>
    <?php default: ?>
        <section class="section-box mt-50 job-of-the-day">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp">
                        <?php echo BaseHelper::clean($shortcode->title); ?>

                    </h2>
                    <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp">
                        <?php echo BaseHelper::clean($shortcode->subtitle); ?>

                    </p>
                    <?php if(count($categories)): ?>
                        <div class="list-tabs mt-40">
                            <div class="nav nav-tabs" role="tablist">
                                <?php $__currentLoopData = $categories->loadMissing('metadata'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div role="tab">
                                        <a
                                            class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $loop->first, 'category-item']); ?>"
                                            id="nav-tab-job-<?php echo e($category->id); ?>"
                                            href="#tab-job-<?php echo e($category->id); ?>"
                                            data-url="<?php echo e(route('public.ajax.jobs-by-category', $category->getKey())); ?>?limit=<?php echo e((int)$shortcode->limit ?: 8); ?>"
                                            data-style="<?php echo e($shortcode->style); ?>"
                                        >
                                            <?php if($iconImage = $category->getMetaData('icon_image', true)): ?>
                                                <img src="<?php echo e(RvMedia::getImageUrl($iconImage)); ?>" alt="<?php echo e($category->name); ?>">
                                            <?php elseif($icon = $category->getMetaData('icon', true)): ?>
                                                <i class="<?php echo e($icon); ?>"></i>
                                            <?php endif; ?>
                                            <?php echo e($category->name); ?>

                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if(count($categories)): ?>
                    <div class="mt-70">
                        <div class="tab-content" id="myTabContent-1">
                            <div
                                class="<?php echo \Illuminate\Support\Arr::toCssClasses(['tab-pane fade show active']); ?>"
                                id="tab-job-<?php echo e($firstCategoryId = $categories->first()->id); ?>"
                                aria-labelledby="tab-job-<?php echo e($firstCategoryId); ?>"
                            >
                                <div class="row job-of-the-day-list">
                                    <?php echo $__env->make(Theme::getThemeNamespace('views.job-board.partials.job-of-the-day-items'), [
                                        'jobs' => $jobs,
                                        'style' => $shortcode->style,
                                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php break; ?>
<?php endswitch; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/shortcodes/job-of-the-day.blade.php ENDPATH**/ ?>