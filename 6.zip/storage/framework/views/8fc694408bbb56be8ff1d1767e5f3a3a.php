<div <?php echo e($attributes->merge(['class' => 'card-body'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/base/resources/views/components/card/body/index.blade.php ENDPATH**/ ?>