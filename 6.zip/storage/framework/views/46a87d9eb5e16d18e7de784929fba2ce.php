<thead <?php echo e($attributes); ?>>
    <tr>
        <?php echo e($slot); ?>

    </tr>
</thead>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/base/resources/views/components/table/header/index.blade.php ENDPATH**/ ?>