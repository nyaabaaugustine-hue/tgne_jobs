<?php
    $currencies = get_all_currencies();
?>

<?php if($currencies->count() > 1): ?>
    <div class="dropdown d-inline-block currency-switch">
        <a
            class="btn-currency-footer dropdown-toggle"
            data-bs-toggle="dropdown"
            type="button"
            href="#"
            aria-haspopup="true"
            aria-expanded="false"
        >
            <?php echo e(get_application_currency()->title); ?>

        </a>
        <div class="dropdown-menu dropdown-menu-end">
            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a
                    class="dropdown-item notify-item language"
                    href="<?php echo e(route('public.change-currency', $currency->title)); ?>"
                ><span><?php echo e($currency->title); ?></span></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/plugins/job-board/resources/views/themes/dashboard/partials/currency-switcher.blade.php ENDPATH**/ ?>