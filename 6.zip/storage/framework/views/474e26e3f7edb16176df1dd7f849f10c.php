<?php switch($shortcode->style):
    case ('style-5'): ?>
        <section class="section-box mt-50 mb-30 bg-brand-2 pt-60 pb-60">
            <div class="container">
                <div class="row">
                    <div class="col-xl-5">
                        <div class="pt-70">
                            <h2 class="color-white mb-20"><?php echo BaseHelper::clean($shortcode->title); ?></h2>
                            <p class="color-white mb-30"><?php echo BaseHelper::clean($shortcode->subtitle); ?></p>
                            <?php if($categoriesPageURL = JobBoardHelper::getJobCategoriesPageURL()): ?>
                                <div class="mt-20">
                                    <a class="btn btn-brand-1 btn-icon-more hover-up" href="<?php echo e($categoriesPageURL); ?>"><?php echo e(__('Explore')); ?></a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-xl-7">
                        <div class="box-swiper mt-50 layout-brand-1">
                            <div class="swiper-container swiper-group-3-explore mh-none swiper">
                                <div class="swiper-wrapper pb-70 pt-5">
                                    <?php $__currentLoopData = $categories->loadMissing('metadata'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="swiper-slide hover-up">
                                            <div class="card-grid-5 card-category hover-up" style="background-image: url('<?php echo e(RvMedia::getImageUrl($category->getMetaData('job_category_image', true)) ?: Theme::asset()->url('imgs/page/homepage2/img-big1.png')); ?>')">
                                                <a href="<?php echo e($category->url); ?>">
                                                    <div class="box-cover-img">
                                                        <div class="content-bottom">
                                                            <h6 class="color-white mb-5"><?php echo e($category->name); ?></h6>
                                                            <p class="color-white font-xs">
                                                                <?php echo __('<span>:count</span> <span>Jobs Available</span>', ['count' => $category->active_jobs_count]); ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="swiper-button-next swiper-button-next-1"></div>
                            <div class="swiper-button-prev swiper-button-prev-1"> </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php break; ?>
    <?php default: ?>
        <section class="section-box mt-50">
            <div class="section-box wow animate__animated animate__fadeIn">
                <div class="container">
                    <div class="text-start">
                        <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp"><?php echo BaseHelper::clean($shortcode->title); ?></h2>
                        <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp"><?php echo BaseHelper::clean($shortcode->subtitle); ?></p>
                    </div>
                    <div class="box-swiper mt-50">
                        <div class="swiper-container swiper-group-6 mh-none swiper">
                            <div class="swiper-wrapper pb-70 pt-5">
                                <?php $__currentLoopData = $categories->loadMissing('metadata'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide hover-up">
                                        <div class="card-grid-5 card-category hover-up" style="background-image: url('<?php echo e(MetaBox::getMetaData($category, 'job_category_image', true) ? RvMedia::getImageUrl(MetaBox::getMetaData($category, 'job_category_image', true)) : Theme::asset()->url('imgs/page/homepage2/img-big1.png')); ?>')">
                                            <a href="<?php echo e($category->url); ?>">
                                                <div class="box-cover-img">
                                                    <div class="content-bottom">
                                                        <h6 class="color-white mb-5"><?php echo e($category->name); ?></h6>
                                                        <p class="color-white font-xs">
                                                            <span><?php echo e($category->active_jobs_count); ?></span>
                                                            <span><?php echo e(__('Jobs Available')); ?></span>
                                                        </p>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="swiper-button-next swiper-button-next-1"></div>
                        <div class="swiper-button-prev swiper-button-prev-1"></div>
                    </div>
                </div>
            </div>
        </section>
    <?php break; ?>
<?php endswitch; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/shortcodes/popular-category.blade.php ENDPATH**/ ?>