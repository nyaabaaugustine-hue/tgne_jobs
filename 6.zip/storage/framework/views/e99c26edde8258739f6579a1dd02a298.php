<div class="page-header d-print-none">
    <div class="<?php echo e(AdminAppearance::getContainerWidth()); ?>">
        <div class="row g-2 align-items-center">
            <div class="col">
                <div class="page-pretitle">
                    <?php echo e(Breadcrumb::default()); ?>

                </div>
            </div>
            <div class="col-auto ms-auto d-print-none">
                <div class="btn-list">
                    <?php echo $__env->yieldPushContent('header-action'); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/base/resources/views/layouts/partials/page-header.blade.php ENDPATH**/ ?>