<?php echo $__env->make('core/base::layouts.' . AdminAppearance::getCurrentLayout() . '.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="d-block d-lg-flex">

<?php echo $__env->make('core/base::layouts.' . AdminAppearance::getCurrentLayout() . '.partials.aside', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/base/resources/views/layouts/vertical/partials/before-content.blade.php ENDPATH**/ ?>