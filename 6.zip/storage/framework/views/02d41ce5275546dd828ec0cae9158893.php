<?php if($locations->count() > 0): ?>
    <?php switch($style):
        case ('style-2'): ?>
            <section class="section-box mt-50">
                <div class="container">
                    <div class="text-start">
                        <?php if($title): ?>
                            <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp"><?php echo e($title); ?></h2>
                        <?php endif; ?>

                        <?php if($description): ?>
                            <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp"><?php echo e($description); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="container">
                        <div class="row mt-50">
                            <?php $__currentLoopData = $locations->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $jobListUrl = $location instanceof \Botble\Location\Models\City ? route('public.jobs-by-city', $location->slug) : route('public.jobs-by-state', $location->slug);
                                    ?>
                                    <div class="col-xl-<?php echo e(3 + $loop->index); ?> col-lg-<?php echo e(3 + $loop->index); ?> col-md-5 col-sm-12 col-12">
                                        <div class="card-image-top hover-up">
                                            <a href="<?php echo e($jobListUrl); ?>" aria-label="<?php echo e($location->name); ?>">
                                                <div class="image" style="background-image: url(<?php echo e($location->image ? RvMedia::getImageUrl($location->image) : Theme::asset()->url('imgs/page/homepage1/location1.png')); ?>);"></div>
                                            </a>
                                            <div class="informations">
                                                <a href="<?php echo e($jobListUrl); ?>">
                                                    <div class="h5 fw-bold"><?php echo e(($location->name)); ?>, <?php echo e($location->country->name); ?></div>
                                                </a>
                                                <div class="row">
                                                    <div class="col-lg-6 col-6">
                                                    <span class="text-14 color-text-paragraph-2">
                                                        <?php if($location->companies_count > 1): ?>
                                                            <?php echo e(__(':count companies', ['count' => $location->companies_count])); ?>

                                                        <?php elseif($location->companies_count == 1): ?>
                                                            <?php echo e(__(':count company', ['count' => $location->companies_count])); ?>

                                                        <?php else: ?>
                                                            <?php echo e(__('No company')); ?>

                                                        <?php endif; ?>
                                                    </span>
                                                    </div>
                                                    <div class="col-lg-6 col-6 text-end">
                                                    <span class="color-text-paragraph-2 text-14">
                                                        <?php if($location->jobs_count > 1): ?>
                                                            <?php echo e(__(':count jobs', ['count' => $location->jobs_count])); ?>

                                                        <?php elseif($location->jobs_count == 1): ?>
                                                            <?php echo e(__(':count job', ['count' => $location->jobs_count])); ?>

                                                        <?php else: ?>
                                                            <?php echo e(__('No jobs')); ?>

                                                        <?php endif; ?>
                                                    </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </section>
            <?php break; ?>
        <?php default: ?>
            <section class="section-box mt-50 job-by-location">
                <div class="container">
                    <div class="text-center">
                        <?php if($title): ?>
                            <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp"><?php echo e($title); ?></h2>
                        <?php endif; ?>

                        <?php if($description): ?>
                            <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp"><?php echo e($description); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="container">
                    <div class="row mt-50">
                        <?php
                            $gridClasses = [[3, 4, 5, 4, 5, 3], [5, 7, 7, 5, 7, 5]]
                        ?>
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $jobListUrl = $location instanceof \Botble\Location\Models\City ? route('public.jobs-by-city', $location->slug) : route('public.jobs-by-state', $location->slug);
                            ?>
                            <div class="col-xl-<?php echo e($gridClasses[0][$loop->index]); ?> col-lg-<?php echo e($gridClasses[0][$loop->index]); ?> col-md-<?php echo e($gridClasses[1][$loop->index]); ?> col-sm-12 col-12">
                                <div class="card-image-top hover-up">
                                    <a href="<?php echo e($jobListUrl); ?>" aria-label="<?php echo e($location->name); ?>">
                                        <div class="image" style="background-image: url(<?php echo e($location->image ? RvMedia::getImageUrl($location->image) : Theme::asset()->url('imgs/page/homepage1/location1.png')); ?>);"></div>
                                    </a>
                                    <div class="informations">
                                        <a href="<?php echo e($jobListUrl); ?>">
                                            <div class="h5 fw-bold"><?php echo e(($location->name)); ?>, <?php echo e($location->country->name); ?></div>
                                        </a>
                                        <div class="row">
                                            <div class="col-lg-6 col-6">
                                            <span class="text-14 color-text-paragraph-2">
                                                <?php if($location->companies_count > 1): ?>
                                                    <?php echo e(__(':count companies', ['count' => $location->companies_count])); ?>

                                                <?php elseif($location->companies_count == 1): ?>
                                                    <?php echo e(__(':count company', ['count' => $location->companies_count])); ?>

                                                <?php else: ?>
                                                    <?php echo e(__('No company')); ?>

                                                <?php endif; ?>
                                            </span>
                                            </div>
                                            <div class="col-lg-6 col-6 text-end">
                                            <span class="color-text-paragraph-2 text-14">
                                                <?php if($location->jobs_count > 1): ?>
                                                    <?php echo e(__(':count jobs', ['count' => $location->jobs_count])); ?>

                                                <?php elseif($location->jobs_count == 1): ?>
                                                    <?php echo e(__(':count job', ['count' => $location->jobs_count])); ?>

                                                <?php else: ?>
                                                    <?php echo e(__('No jobs')); ?>

                                                <?php endif; ?>
                                            </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
            <?php break; ?>
    <?php endswitch; ?>
<?php endif; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/shortcodes/job-by-location.blade.php ENDPATH**/ ?>