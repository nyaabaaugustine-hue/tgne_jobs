<button
    type="button"
    class="btn-close"
    data-bs-dismiss="modal"
    aria-label="<?php echo e(trans('core/base::base.close')); ?>"
></button>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/base/resources/views/components/modal/close-button.blade.php ENDPATH**/ ?>