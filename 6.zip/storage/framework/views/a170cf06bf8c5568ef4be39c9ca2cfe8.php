<svg class="icon dropdown-item-icon ms-auto me-0 svg-icon-ti-ti-chevron-right"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
  >
  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
  <path d="M9 6l6 6l-6 6" />
</svg><?php /**PATH C:\Users\TGNE\Pictures\JobBox\storage\framework\views/b3952f2f8079cae92614235bd0a03d56.blade.php ENDPATH**/ ?>