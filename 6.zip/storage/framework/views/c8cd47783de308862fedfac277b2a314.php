<div class="loading-ring">
    <div class="loading-ring-wrapper">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>
</div>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/loading.blade.php ENDPATH**/ ?>