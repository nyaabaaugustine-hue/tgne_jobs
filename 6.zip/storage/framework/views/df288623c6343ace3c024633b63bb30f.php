<tr <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</tr>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/base/resources/views/components/table/body/row.blade.php ENDPATH**/ ?>