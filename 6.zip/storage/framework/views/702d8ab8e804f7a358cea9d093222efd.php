</div>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/base/resources/views/layouts/vertical/partials/after-content.blade.php ENDPATH**/ ?>