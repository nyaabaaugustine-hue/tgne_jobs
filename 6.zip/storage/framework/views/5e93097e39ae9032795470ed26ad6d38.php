<div class="footer-col-6 col-md-3 col-sm-12">
    <div class="h6 mb-20"><?php echo e($config['label']); ?></div>
    <p class="color-text-paragraph-2 font-xs">
        <?php echo BaseHelper::clean(theme_option('app_advertisement')); ?>

    </p>
    <div class="mt-15">
        <?php if($url = $config['app_store_url']): ?>
            <?php if($image = $config['app_store_image']): ?>
                <a class="mr-5" href="<?php echo e($url); ?>">
                    <img src="<?php echo e(RvMedia::getImageUrl($image)); ?>" alt="<?php echo e(__('App Store')); ?>">
                </a>
            <?php endif; ?>
        <?php endif; ?>
        <?php if($url = $config['android_app_url']): ?>
            <?php if($image = $config['google_play_image']): ?>
                <a class="mr-5" href="<?php echo e($url); ?>">
                    <img src="<?php echo e(RvMedia::getImageUrl($image)); ?>" alt="<?php echo e(__('Google Play')); ?>">
                </a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/////widgets/download/templates/frontend.blade.php ENDPATH**/ ?>