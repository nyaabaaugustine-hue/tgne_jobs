<section class="section-box mt-50">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 mb-15 mb-lg-0">
                <div class="box-radius-8 bg-urgent hover-up">
                    <?php if($url = $shortcode->image_of_first_content): ?>
                        <div class="image">
                            <figure>
                                <img src="<?php echo e(RvMedia::getImageUrl($url)); ?>" alt="<?php echo e($shortcode->first_image_alt_text); ?>">
                            </figure>
                        </div>
                    <?php endif; ?>
                    <div class="text-info">
                        <h3><?php echo BaseHelper::clean($shortcode->first_title); ?></h3>
                        <p class="font-sm color-text-paragraph-2"><?php echo BaseHelper::clean($shortcode->first_description); ?></p>
                        <?php if($shortcode->load_more_link_first_content && $shortcode->load_more_first_content_text ): ?>
                            <div class="mt-15">
                                <a class="btn btn-arrow-right" href="<?php echo e($shortcode->load_more_link_first_content); ?>">
                                    <?php echo BaseHelper::clean($shortcode->load_more_first_content_text); ?>

                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="box-radius-8 bg-9 hover-up">
                    <?php if($url = $shortcode->image_of_second_content): ?>
                        <div class="image">
                            <figure>
                                <img src="<?php echo e(RvMedia::getImageUrl($url)); ?>" alt="<?php echo BaseHelper::clean($shortcode->second_image_alt_text); ?>">
                            </figure>
                        </div>
                    <?php endif; ?>
                    <div class="text-info">
                        <h3><?php echo BaseHelper::clean($shortcode->second_title); ?></h3>
                        <p class="font-sm color-text-paragraph-2">
                            <?php echo BaseHelper::clean($shortcode->second_description ); ?>

                        </p>
                        <?php if($shortcode->load_more_link_second_content && $shortcode->load_more_second_content_text): ?>
                            <div class="mt-15">
                                <a class="btn btn-arrow-right" href="<?php echo e($shortcode->load_more_link_second_content); ?>">
                                    <?php echo BaseHelper::clean($shortcode->load_more_second_content_text); ?>

                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/shortcodes/advertisement-banner.blade.php ENDPATH**/ ?>