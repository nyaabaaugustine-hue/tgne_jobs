<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('core/table::base-table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout ?? BaseHelper::getAdminMasterLayoutTemplate(), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform/core/table/resources/views/table.blade.php ENDPATH**/ ?>