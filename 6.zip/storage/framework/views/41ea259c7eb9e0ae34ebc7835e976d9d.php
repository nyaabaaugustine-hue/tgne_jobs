<?php switch($shortcode->style):
    case ('style-2'): ?>
        <section class="section-box mt-50 top-companies">
            <div class="container">
                <div class="text-start">
                    <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp"><?php echo BaseHelper::clean($shortcode->title); ?></h2>
                    <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp"><?php echo BaseHelper::clean($shortcode->description); ?></p>
                </div>
            </div>
            <div class="container">
                <div class="box-swiper mt-50">
                    <div class="swiper-container swiper-group-1 swiper-style-2 swiper">
                        <div class="swiper-wrapper pt-5">
                            <div class="swiper-slide">
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item-5 hover-up wow animate__animated animate__fadeIn">
                                        <div class="item-logo">
                                            <a href="<?php echo e($company->url); ?>">
                                                <?php if($company->logo): ?>
                                                    <div class="image-left">
                                                        <img alt="<?php echo e($company->name); ?>" src="<?php echo e($company->logo_thumb); ?>">
                                                    </div>
                                                <?php endif; ?>
                                                <div class="text-info-right">
                                                    <h4><?php echo e($company->name); ?></h4>
                                                    <?php if(JobBoardHelper::isEnabledReview()): ?>
                                                        <?php echo Theme::partial('rating-star', ['star' => round($company->reviews_avg_star)]); ?>

                                                        <span class="font-xs color-text-mutted ml-10">
                                                        <span>
                                                            (</span><span><?php echo e($company->reviews_count); ?></span><span>)
                                                        </span>
                                                    </span>
                                                    <?php endif; ?>
                                                </div>
                                            </a>
                                            <div class="text-info-bottom mt-5 text-truncate">
                                                <span class="font-xs color-text-mutted icon-location location-label" title="<?php echo e($company->state_name ? $company->state_name . ', ' : ''); ?> <?php echo e($company->country->code); ?>">
                                                    <?php echo e($company->state_name ? $company->state_name . ', ' : ''); ?> <?php echo e($company->country->code); ?> &nbsp;
                                                </span>
                                                <span class="font-xs color-text-mutted float-end mt-5">
                                                    <?php echo $__env->make(Theme::getThemeNamespace('partials.job-count'), ['company' => $company], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-button-next swiper-button-next-1"></div>
                    <div class="swiper-button-prev swiper-button-prev-1"></div>
                </div>
            </div>
        </section>
        <?php break; ?>
    <?php case ('style-3'): ?>
        <section class="section-box mt-50 top-companies">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp"><?php echo BaseHelper::clean($shortcode->title); ?></h2>
                    <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp"><?php echo BaseHelper::clean($shortcode->description); ?></p>
                </div>
            </div>
            <div class="container">
                <div class="box-swiper mt-50">
                    <div class="swiper-container swiper-group-1 swiper-style-2 swiper">
                        <div class="swiper-wrapper pt-5">
                            <div class="swiper-slide">
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item-5 hover-up wow animate__animated animate__fadeIn">
                                        <div class="item-logo">
                                            <a href="<?php echo e($company->url); ?>">
                                                <?php if($company->logo): ?>
                                                    <div class="image-left">
                                                        <img alt="<?php echo e($company->name); ?>" src="<?php echo e($company->logo_thumb); ?>">
                                                    </div>
                                                <?php endif; ?>
                                                <div class="text-info-right">
                                                    <h4><?php echo e($company->name); ?></h4>
                                                    <?php if(JobBoardHelper::isEnabledReview()): ?>
                                                        <?php echo Theme::partial('rating-star', ['star' => round($company->reviews_avg_star)]); ?>

                                                        <span class="font-xs color-text-mutted ml-10">
                                                            <span>
                                                                (</span><span><?php echo e($company->reviews_count); ?></span><span>)
                                                            </span>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </a>
                                            <div class="text-info-bottom mt-5">
                                                <span class="font-xs color-text-mutted icon-location location-label" title="<?php echo e($company->state_name ? $company->state_name . ', ' : ''); ?> <?php echo e($company->country->code); ?>">
                                                    <?php echo e($company->state_name ? $company->state_name . ', ' : ''); ?> <?php echo e($company->country->code); ?>

                                                </span>
                                                <span class="font-xs color-text-mutted float-end mt-5">
                                                    <?php echo $__env->make(Theme::getThemeNamespace('partials.job-count'), ['company' => $company], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-button-next swiper-button-next-1"></div>
                    <div class="swiper-button-prev swiper-button-prev-1"></div>
                </div>
            </div>
        </section>
        <?php break; ?>
    <?php default: ?>
        <section class="section-box mt-50 top-companies">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp"><?php echo BaseHelper::clean($shortcode->title); ?></h2>
                    <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp"><?php echo BaseHelper::clean($shortcode->description); ?></p>
                </div>
            </div>
            <div class="container">
                <div class="box-swiper mt-50">
                    <div class="swiper-container swiper-group-1 swiper-style-2 swiper">
                        <div class="swiper-wrapper pt-5">
                            <div class="swiper-slide">
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item-5 hover-up wow animate__animated animate__fadeIn">
                                        <div class="item-logo">
                                            <a href="<?php echo e($company->url); ?>">
                                                <?php if($company->logo): ?>
                                                    <div class="image-left">
                                                        <img alt="<?php echo e($company->name); ?>" src="<?php echo e($company->logo_thumb); ?>">
                                                    </div>
                                                <?php endif; ?>
                                                <div class="text-info-right">
                                                    <h4><?php echo e($company->name); ?></h4>
                                                    <?php if(JobBoardHelper::isEnabledReview()): ?>
                                                        <?php echo Theme::partial('rating-star', ['star' => round($company->reviews_avg_star)]); ?>

                                                        <span class="font-xs color-text-mutted ml-10">
                                                        <span>
                                                            (</span><span><?php echo e($company->reviews_count); ?></span><span>)
                                                        </span>
                                                    </span>
                                                    <?php endif; ?>
                                                </div>
                                            </a>
                                            <div class="text-info-bottom mt-5">
                                                <span class="font-xs color-text-mutted icon-location location-label" title="<?php echo e($company->state_name ? $company->state_name . ', ' : ''); ?> <?php echo e($company->country->code); ?>">
                                                    <?php echo e($company->state_name ? $company->state_name . ', ' : ''); ?> <?php echo e($company->country->code); ?>

                                                </span>
                                                <span class="font-xs color-text-mutted float-end mt-5">
                                                    <?php echo $__env->make(Theme::getThemeNamespace('partials.job-count'), ['company' => $company], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <?php if($companies->count() > 15): ?>
                        <div class="swiper-button-next swiper-button-next-1"></div>
                        <div class="swiper-button-prev swiper-button-prev-1"></div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php break; ?>
<?php endswitch; ?>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/shortcodes/top-companies.blade.php ENDPATH**/ ?>