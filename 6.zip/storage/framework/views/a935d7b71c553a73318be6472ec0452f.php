<?php if(theme_option('preloader_enabled', 'yes') == 'yes'): ?>
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if(is_plugin_active('job-board')): ?>
    <?php echo $__env->make(Theme::getThemeNamespace('partials.apply-modal'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>
<header class="header <?php if(theme_option('enabled_sticky_header', 'yes') == 'yes'): ?> sticky-bar <?php endif; ?>">
    <div class="container">
        <div class="main-header">
            <div class="header-left">
                <div class="header-logo">
                    <a class="d-flex" href="<?php echo e(route('public.index')); ?>">
                        <img alt="<?php echo e(theme_option('site_title')); ?>" src="<?php echo e(setting('theme-jobbox-logo') ? RvMedia::getImageUrl(setting('theme-jobbox-logo')) : url(config('core.base.general.logo'))); ?>">
                    </a>
                </div>
            </div>
            <div class="header-nav">
                <nav class="nav-main-menu">
                    <?php echo Menu::renderMenuLocation('main-menu', [
                            'options' => ['class' => 'main-menu'],
                            'view'    => 'main-menu',
                        ]); ?>

                </nav>
                <div class="burger-icon burger-icon-white">
                    <span class="burger-icon-top"></span>
                    <span class="burger-icon-mid"></span>
                    <span class="burger-icon-bottom"></span>
                </div>
            </div>
            <div class="header-right">
                <?php if(is_plugin_active('job-board')): ?>
                    <?php if(auth()->guard('account')->check()): ?>
                        <ul class="header-menu list-inline d-flex align-items-center mb-0 user-header-dropdown">
                            <?php echo apply_filters('theme-header-right-nav', null); ?>

                            <?php if(auth('account')->check() && $account = auth('account')->user()): ?>
                                <li class="list-inline-item dropdown">
                                    <a href="#" class="d-inline-flex header-item" id="userdropdown" data-bs-toggle="dropdown"
                                       aria-expanded="false">
                                        <img src="<?php echo e($account->avatar_thumb_url); ?>" alt="<?php echo e($account->name); ?>" width="35" height="35" class="rounded-circle me-1 mt-1 mr-2">
                                        <span class="text-left fw-medium icon-down" title="<?php echo e(__('Hi, :name', ['name' => $name = Str::limit($account->name, 15)])); ?>"><?php echo e(__('Hi, :name', ['name' => $name])); ?> </span>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-end user-dropdown-menu" aria-labelledby="userdropdown">
                                        <?php if($account->isEmployer()): ?>
                                            <li><a class="dropdown-item" href="<?php echo e(route('public.account.dashboard')); ?>"><?php echo e(__('Employer Dashboard')); ?></a></li>
                                        <?php else: ?>
                                            <li><a class="dropdown-item" href="<?php echo e(route('public.account.jobs.saved')); ?>"><?php echo e(__('Saved Jobs')); ?></a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(route('public.account.jobs.applied-jobs')); ?>"><?php echo e(__('Applied Jobs')); ?></a></li>
                                        <?php endif; ?>
                                        <li><a class="dropdown-item" href="<?php echo e(route('public.account.settings')); ?>"><?php echo e(__('Account Settings')); ?></a></li>
                                        <li>
                                            <a class="dropdown-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" href="#"><?php echo e(__('Logout')); ?></a>
                                            <form id="logout-form" action="<?php echo e(route('public.account.logout')); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                        </ul>
                    <?php else: ?>
                        <div class="block-signin">
                            <a class="text-link-bd-btom hover-up" href="<?php echo e(route('public.account.register')); ?>"><?php if (isset($component)) { $__componentOriginal73995948b3bd877b76251b40caf28170 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73995948b3bd877b76251b40caf28170 = $attributes; } ?>
<?php $component = Botble\Icon\View\Components\Icon::resolve(['name' => 'ti ti-user-plus'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('core::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Botble\Icon\View\Components\Icon::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'me-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73995948b3bd877b76251b40caf28170)): ?>
<?php $attributes = $__attributesOriginal73995948b3bd877b76251b40caf28170; ?>
<?php unset($__attributesOriginal73995948b3bd877b76251b40caf28170); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73995948b3bd877b76251b40caf28170)): ?>
<?php $component = $__componentOriginal73995948b3bd877b76251b40caf28170; ?>
<?php unset($__componentOriginal73995948b3bd877b76251b40caf28170); ?>
<?php endif; ?><?php echo e(__('Register')); ?></a>
                            <a class="btn btn-default btn-shadow ml-30 hover-up" href="<?php echo e(route('public.account.login')); ?>"><?php if (isset($component)) { $__componentOriginal73995948b3bd877b76251b40caf28170 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73995948b3bd877b76251b40caf28170 = $attributes; } ?>
<?php $component = Botble\Icon\View\Components\Icon::resolve(['name' => 'ti ti-user-shield'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('core::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Botble\Icon\View\Components\Icon::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'me-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73995948b3bd877b76251b40caf28170)): ?>
<?php $attributes = $__attributesOriginal73995948b3bd877b76251b40caf28170; ?>
<?php unset($__attributesOriginal73995948b3bd877b76251b40caf28170); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73995948b3bd877b76251b40caf28170)): ?>
<?php $component = $__componentOriginal73995948b3bd877b76251b40caf28170; ?>
<?php unset($__componentOriginal73995948b3bd877b76251b40caf28170); ?>
<?php endif; ?><?php echo e(__('Sign In')); ?></a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>
<div class="mobile-header-active mobile-header-wrapper-style perfect-scrollbar">
    <div class="offcanvas-header justify-content-end">
        <button type="button" class="btn-close burger-close burger-icon" aria-label="Close"></button>
    </div>
    <div class="mobile-header-wrapper-inner">
        <div class="mobile-header-content-area">
            <div class="perfect-scroll">
                <div class="mobile-search mobile-header-border mb-30">
                    <form action="#">
                        <input type="text" placeholder="<?php echo e(__('Search...')); ?>">
                        <i class="fi-rr-search"></i>
                    </form>
                </div>
                <div class="mobile-menu-wrap mobile-header-border">
                    <nav>
                        <?php echo Menu::renderMenuLocation('main-menu', [
                                'options' => ['class' => 'mobile-menu font-heading'],
                                'view'    => 'main-menu',
                            ]); ?>

                        <?php if(is_plugin_active('language')): ?>
                            <?php echo Theme::partial('language-and-currency-switcher-mobile'); ?>

                        <?php endif; ?>
                    </nav>
                </div>
                <?php if(is_plugin_active('job-board')): ?>
                    <?php if(auth()->guard('account')->check()): ?>
                        <div class="mobile-account">
                            <h6 class="mb-10"><?php echo e(__('Your Account')); ?></h6>
                            <ul class="mobile-menu font-heading">
                                <?php if(auth('account')->user()->isEmployer()): ?>
                                    <li><a href="<?php echo e(route('public.account.dashboard')); ?>"><?php echo e(__('Employer Dashboard')); ?></a></li>
                                <?php else: ?>
                                    <li><a href="<?php echo e(route('public.account.jobs.saved')); ?>"><?php echo e(__('Saved Jobs')); ?></a></li>
                                    <li><a href="<?php echo e(route('public.account.jobs.applied-jobs')); ?>"><?php echo e(__('Applied Jobs')); ?></a></li>
                                <?php endif; ?>
                                <li><a href="<?php echo e(route('public.account.settings')); ?>"><?php echo e(__('Account Settings')); ?></a></li>
                                <li><a href="<?php echo e(route('public.account.logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit()"><?php echo e(__('Sign Out')); ?></a></li>
                            </ul>
                        </div>
                        <form id="logout-form" action="<?php echo e(route('public.account.logout')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                        </form>
                    <?php else: ?>
                        <div class="mobile-account">
                            <ul class="mobile-menu font-heading">
                                <li><a href="<?php echo e(route('public.account.login')); ?>"><?php if (isset($component)) { $__componentOriginal73995948b3bd877b76251b40caf28170 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73995948b3bd877b76251b40caf28170 = $attributes; } ?>
<?php $component = Botble\Icon\View\Components\Icon::resolve(['name' => 'ti ti-user-plus'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('core::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Botble\Icon\View\Components\Icon::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'me-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73995948b3bd877b76251b40caf28170)): ?>
<?php $attributes = $__attributesOriginal73995948b3bd877b76251b40caf28170; ?>
<?php unset($__attributesOriginal73995948b3bd877b76251b40caf28170); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73995948b3bd877b76251b40caf28170)): ?>
<?php $component = $__componentOriginal73995948b3bd877b76251b40caf28170; ?>
<?php unset($__componentOriginal73995948b3bd877b76251b40caf28170); ?>
<?php endif; ?><?php echo e(__('Sign In')); ?></a></li>
                                <li><a href="<?php echo e(route('public.account.register')); ?>"><?php if (isset($component)) { $__componentOriginal73995948b3bd877b76251b40caf28170 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73995948b3bd877b76251b40caf28170 = $attributes; } ?>
<?php $component = Botble\Icon\View\Components\Icon::resolve(['name' => 'ti ti-user-shield'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('core::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Botble\Icon\View\Components\Icon::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'me-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73995948b3bd877b76251b40caf28170)): ?>
<?php $attributes = $__attributesOriginal73995948b3bd877b76251b40caf28170; ?>
<?php unset($__attributesOriginal73995948b3bd877b76251b40caf28170); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73995948b3bd877b76251b40caf28170)): ?>
<?php $component = $__componentOriginal73995948b3bd877b76251b40caf28170; ?>
<?php unset($__componentOriginal73995948b3bd877b76251b40caf28170); ?>
<?php endif; ?><?php echo e(__('Sign Up')); ?></a></li>
                            </ul>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                <div class="site-copyright"><?php echo BaseHelper::clean(theme_option('copyright')); ?></div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\TGNE\Pictures\JobBox\platform\themes/jobbox/partials/navbar.blade.php ENDPATH**/ ?>